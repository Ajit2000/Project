<?php include_once 'database.php';?>

<?php 
if(isset($_POST['id'])){
    
session_start();
$Email = $_SESSION['Email'];
$cname = "";
$total = 0;
$pnames = "";
$query="SELECT * FROM registertable WHERE Email = '$Email' ";
$res=mysqli_query($conn,$query);
if($res){
    if(mysqli_num_rows($res)>0){
        while($rows=mysqli_fetch_assoc($res)){
            $cname = $rows['First_Name']." ".$rows['Last_Name'];
            $address = $rows['Address'];
        }
    }
}
    for($i=0;$i<sizeof($_POST['id']);$i++){
        $id = $_POST["id"][$i];
        $query = " SELECT * FROM carttable WHERE Email = '$Email' AND Product_Id = '$id'";
        $res = mysqli_query($conn,$query);
        if($res){
            if(mysqli_num_rows($res)>0){
                while($rows=mysqli_fetch_assoc($res)){
                    $pnames = $pnames." ".$rows['Product_Name'].", ";
                    $total = $total + ( $_POST['quantity'][$i] * $rows['Product_Price'] );
            }
        }
    }
}
        mysqli_close($conn);
?>
<html>
    <head>
        <link rel="stylesheet", href="./css/style2.css"> 
    </head>
    <body>
        <div class="banner">
            <div class="bill">
                <h1>Online Shopping Portal</h1>
                <h3>Bill Generated</h3>
                <table>
                    <tr>
                        <td>Customer Name</td>
                        <td><?php echo $cname  ?></td>
                    </tr>
                    <tr>
                        <td>Customer Email</td>
                        <td><?php echo $Email  ?></td>
                    </tr>
                    <tr>
                        <td>Product Names</td>
                        <td><?php echo $pnames  ?></td>
                    </tr>
                    <tr>
                        <td>Total Amount</td>
                        <td>₹ <?php echo $total ?></td>
                    </tr>
                    <tr>
                    <td colspan="2"><button type="submit" name="submit">Payment</button>
                        </tr>
                    <tr>
                        <form action="./CODorder.php" method="post">
                        <input type="hidden" name="cname" value="<?php echo $cname ?>">
                        <input type="hidden" name="cemail" value="<?php echo $Email  ?>">
                        <input type="hidden" name="pname" value="<?php echo $pnames  ?>">
<!--                        <input type="hidden" name="pid" value="<?php echo $pid  ?>">-->
                        <input type="hidden" name="amount" value="<?php echo $total ?>">
                        <input type="hidden" name="address" value="<?php echo $address ?>">
                        <td colspan="2"><button type="submit" name="submit">COD</button></td>
                        </form>
                    </tr>

                </table>
            </div>
        </div>
    </body>
</html>
<?php 
        }else{
                header("Location:./mycart.php");
              }
?>    