<?php include_once '../database.php';?>
<?php 
if(isset($_GET['x'])){
    $user = $_GET['x'];
    $query="DELETE FROM `registertable` WHERE Email = '$user'";

    $res=mysqli_query($conn,$query);
    if($res){
        header('Location:./customers.php');
    }else{
        echo "<h1>NOT DELETED</h1>";
    }

}


?>