<?php include_once '../database.php';?>

<?php 
$Name =null;
session_start();
 if(isset($_SESSION['Email'])){
     $Email = $_SESSION['Email'];
 }else{
     $Email = null;
 }
 
 $query="SELECT * FROM admintable WHERE Email = '$Email'";

    $res=mysqli_query($conn,$query);
    if($res){ 
		if(mysqli_num_rows($res)>0){
			while($row=mysqli_fetch_assoc($res)){
				$Name = $row['First_Name']." ".$row['Last_Name'];   
			}
        }
	}
?>


<html>
    <head>
        <link rel="stylesheet", href="../css/style.css">  
    </head>
    <body>
        <div class="banner">
            <div class="navbar">
                <h2>ONLINE SHOPPING PORTAL</h2>
                <ul>
                    <li><a href="./adminpage.php">HOME</a></li>
                    <li><a href="./customers.php">customers</a></li>
                    <li><a href="./manageProducts.php"s>manageproducts</a></li>
<!--                    <li><a href="./contactus.php"></a>Add admin</li>-->
					<?php 
					if(isset($Name)){
					?>
                    <li style="color:white ; text-transform: uppercase;"><?php echo $Name  ?></li>
					<li><a href="../logout.php">Logout</a></li>
					<?php } ?>
                </ul>
            </div>
            
            <div class="content">
                <h1>ONLINE SHOPPING PORTAL</h1>
                <p>This is a home page for the online shopping portal project</p>
                <?php 
				if(!isset($Name)){
				?>
                <div>
                    <a href = "login.php"><button type="button" class="button-style"><span></span>LOGIN</button></a>
                    <a href = "register.php"><button type="button" class="button-style"><span></span>REGISTER</button></a>
                </div> 
                <?php }?>
            </div>
        </div>
        
         <div class="social-icon">
        <a href="#">
            <i class="fa fa-envelope" aria-hidden="true"></i>
            <h3>shopname@gmail.com</h3>
        </a>
        <a href="#">
           <i class="fa fa-map-marker" aria-hidden="true"></i>
            <h3>Address</h3>
        </a>
        <a href="#">
            <i class="fa fa-phone-square" aria-hidden="true"></i>
            <h3>1234567890</h3>
        </a>
        </div>
    </body>
</html>