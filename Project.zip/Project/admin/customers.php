<?php include_once '../database.php';?>
<html>
    <head>
        <link rel="stylesheet", href="../css/style2.css">
    </head>
    <body>
        <div class="customerHeading">
            <h1>Customer Information</h1>
        </div>
<?php

$query="SELECT * FROM registertable";

    $res=mysqli_query($conn,$query);
    if($res){		
    if(mysqli_num_rows($res)>0){
        while($row=mysqli_fetch_assoc($res)){
?>

        <div class="infoC">
            <h2> Name: <?php echo $row['First_Name']?> <?php echo $row['Last_Name']?> <br/> Email: <?php echo $row['Email']?> <br/> Phone No.: <?php echo $row['Mobile_Number']?> <br/> Address: <?php echo $row['Address']?>.</h2>
        </div>
<?php
        }
    }
        mysqli_close($conn);
}


?>
    </body>
</html>