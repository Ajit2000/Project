<?php include_once '../database.php';?>
<?php 
if(isset($_POST['add']))
{
         #upload code 
        $target_dir = "../images/";
        $target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
        $uploadOk = 1;
        $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
        // Check if image file is a actual image or fake image
        if(isset($_POST["submit"])) {
            $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
            if($check !== false) {
                echo "File is an image - " . $check["mime"] . ".";
                $uploadOk = 1;
            } else {
                echo "File is not an image.";
                $uploadOk =0;
            }
        }
        // Check if file already exists
        if(file_exists($target_file)) {
            echo "Sorry, file already exists.";
            $uploadOk =0;
        }
        // Check file size
        if($_FILES["fileToUpload"]["size"] > 500000) {
            echo "Sorry, your file is too large.";
            $uploadOk = 0;
        }
        // Allow certain file formats
        if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
        && $imageFileType != "gif" ) {
            echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
            $uploadOk = 0;
        }
        // Check if $uploadOk is set to 0 by an error
        if($uploadOk == 0) {
            echo "Sorry, your file was not uploaded.";
        // if everything is ok, try to upload file
        } else {
            if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
                echo "The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded.";
            } else {
                echo "Sorry, there was an error uploading your file.";
            }
        }
    
        
        #add to database code
        $Pid=$_POST['pid'];
        $Name=$_FILES["fileToUpload"]["name"];
        $Info=$_POST['info'];
        $Price=$_POST['price'];
		
            $query="INSERT INTO `producttable`(`Product_Id`, `Product_Name`, `Product_Info`, `Product_Price`, `Status`) VALUES ('$Pid','$Name','$Info','$Price','1')";

            $res=mysqli_query($conn,$query);
            if($res)
            {
               // echo "<h1>Record inserted successfully</h1>";
                header("Location:./adminpage.php");
            }else{
                echo "<h1>Record not inserted successfully</h1>";
            }
               mysqli_close($conn);
    

}

?>

<html>
    <head>
        <link rel="stylesheet", href="../css/style.css">  
    </head>
    <body>
    <form action="./manageProducts.php" method="post" enctype="multipart/form-data">
    <div class="banner">
        <div class="contact-us">
            <h1>Add Products</h1>
            
        <div class="txt">
            <label>Product id :</label>
            <input type="text" name="pid" value="" placeholder="Enter Product ID">
        </div>
        
        <div class="txt">
            <label>Product Information :</label>
            <input type="" name="info" value="" placeholder="Enter Product Information">
        </div>
            
        <div class="txt">
            <label>Price :</label>
            <input type="text" name="price" value="" placeholder="Enter Product Price">
        </div> 
        
        <div class="txt">
            <label>Insert Image :</label>
            <input type="file" name="fileToUpload" id="fileToUpload">
        </div>
            
        <button type="submit" name = 'add' class="btn-send">Add Product</button>  
            
        </div> 
    </div>
        </form>
    </body>
</html>


