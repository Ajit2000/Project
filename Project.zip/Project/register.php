<?php include_once 'database.php';?>

<?php 
$error = '';
if(isset($_GET['x']))
{
    $error = $_GET['x'];
}
if(isset($_POST['submit']))
{
        $Fname=$_POST['firstname'];
        $Lname=$_POST['lastname'];
        $address=$_POST['address'];
        $phNo=$_POST['mobileno'];
        $Email=$_POST['email'];
        $password=$_POST['password'];
        $cpassword = $_POST['RPassword'];
		if($password == $cpassword ){
		$sql="SELECT * FROM registertable WHERE Email = '$Email'";
        $result=mysqli_query($conn,$sql);
        if(mysqli_num_rows($result)>0){
            //echo "<small style='color:red' >User is already exits!</small>";
        header("Location:./register.php?x=User is already exits!");
        }else{
         $query="INSERT INTO registertable(First_Name, Last_Name, Address, Mobile_Number, Email, Password) VALUES ('$Fname','$Lname','$address','$phNo','$Email','$password')";

            $res=mysqli_query($conn,$query);
            if($res)
            {
               // echo "<h1>Record inserted successfully</h1>";
                header("Location:./login.php");
            }else{
                echo "<h1>Record not inserted successfully</h1>";
            }
        }
        
    }else{
            header("Location:./register.php?x=Password Not Match!");
        }
    
               mysqli_close($conn);
        
}
?>

<html>
    <head>
        <link rel="stylesheet", href="./css/style.css">  
    </head>
    <body>
	<form action= "" method = "post" >
        <div class="banner">
            <div class="login-box">
            <h1 style="margin : 0 0 20px 20px; ">REGISTER</h1>
            <div class="textbox">
                 <input type="text" placeholder="FirstName" name="firstname" value="">
            </div>
             <div class="textbox">
                 <input type="text" placeholder="LastName" name="lastname" value="">
            </div>
            <div class="textbox">
                 <input type="text" placeholder="Address" name="address" value="">
            </div>
             <div class="textbox">
                 <input type="text" placeholder="MobileNo" name="mobileno" value="" pattern="^\d{10}$" required>
            </div>
            <div class="textbox">
                 <input type="email" placeholder="Email" name="email" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" required>
            </div>
            <div class="textbox">
                 <input type="password" placeholder="Password" name="password" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}"  title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" required>
            </div>
            <div class="textbox">
                 <input type="password" placeholder="RepeatPassword" name="RPassword" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}"  title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" required>
            </div>
                    <button class="button-style" style="width: 100%" type="submit" name = "submit"><span></span>REGISTER</button>
            <div>
                <h3 style="margin: 0 0 0 13px">Already have an Account?</h3>    
            </div>
                <a href = "./login.php"><button class="button-style" style="width: 100%" type="button" ><span></span>LOGIN</button></a>
                
        </div>
        </div>
		</form>
    </body>
</html>