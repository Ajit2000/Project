<?php 
if(isset($_POST['submit'])){
    $email = $_POST['cemail'];
    $otp = rand(10,9999);
    require 'PHPMailerAutoload.php';
    require 'credentials.php';
    $mail = new PHPMailer;

    $mail->SMTPDebug = 3;                               // Enable verbose debug output

    $mail->isSMTP();                                      // Set mailer to use SMTP
    $mail->Host = 'smtp.gmail.com';  // Specify main and backup SMTP servers
    $mail->SMTPAuth = true;                               // Enable SMTP authentication
    $mail->Username = EMAIL;                 // SMTP username
    $mail->Password = PASS;                           // SMTP password
    $mail->SMTPSecure = 'tls';                            // Enable TLS encryption, `ssl` also accepted
    $mail->Port = 587;                                    // TCP port to connect to

    $mail->setFrom(EMAIL, 'Online Shopping Portal');
    $mail->addAddress($email);     // Add a recipient
    //$mail->addAddress('ellen@example.com');               // Name is optional
    $mail->addReplyTo(EMAIL);
    //$mail->addCC('cc@example.com');
    //$mail->addBCC('bcc@example.com');

    //$mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
    //$mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name

    $mail->isHTML(true);                                  // Set email format to HTML

    $mail->Subject = 'OTP for reset Password';
    $mail->Body    = "OTP for Reset Password is <b>".$otp."</b>";
    $mail->AltBody = '';

    if(!$mail->send()) {
        echo 'Message could not be sent.';
        echo 'Mailer Error: ' . $mail->ErrorInfo;
    } else {
            header("Location:./updatePassword.php?x=$email&y=$otp  ");
        }
}
?>

<html>
    <head>
        <link rel="stylesheet", href="./css/style.css">  
    </head>
    <body>
	<form action = "" method = "post">
        <div class="banner">
            <div class="login-box">
            <h1 style="font-size: 28px;">Reset Password</h1>
            <div class="textbox">
                <i class="fa fa-user" aria-hidden="true"></i>
                 <input type="email" placeholder="Username" name="cemail" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" required>
            </div>
                <button type="submit" class="button-style" style="width: 100%" name="submit" ><span></span>Send otp</button>
            </div>
        </div>
        </form>
    </body>
</html>