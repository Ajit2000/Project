<?php include_once 'database.php';?>

<?php
session_start();
$Email = $_SESSION['Email'];
$Pid = $_GET['c'];
$query="DELETE FROM carttable WHERE Email = '$Email' AND Product_Id = '$Pid'";

$res=mysqli_query($conn,$query);
if($res){
     header("Location:./products.php");
    }else{
           echo "Problem in remove";
    }
     mysqli_close($conn);
?>