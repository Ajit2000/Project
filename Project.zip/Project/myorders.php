<?php include_once './database.php';?>
<html>
    <head>
        <link rel="stylesheet", href="./css/style2.css">
        <link rel="stylesheet", href="./css/product.css">
    </head>
    <body>
            <div class="navbar-main">
                <h2>ONLINE SHOPPING PORTAL</h2>
                <ul>
                    <li><a href="./products.php">HOME</a></li>
        </ul>
</div>
        <div class="customerHeading">
            <h1>My Orders</h1>
        </div>
<?php
session_start();
$Email = $_SESSION['Email'];
$query="SELECT * FROM `ordertable` WHERE Email = '$Email'";

    $res=mysqli_query($conn,$query);
    if($res){		
    if(mysqli_num_rows($res)>0){
        while($row=mysqli_fetch_assoc($res)){
?>
        <div class="infoC" style="width:29%">
            <h2> Product Names: <?php 
                        $data = str_split($row['Product_Name']);
                        foreach($data as $a){
                            echo $a;
                            if($a == ","){
                                echo " ";
                            }
                        }
                ?><br/> Amount : <?php echo $row['Amount']?>.</h2>
        </div>

<?php
        }
    }
        mysqli_close($conn);
}
 ?>
</body>
</html>