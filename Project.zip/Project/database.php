<?php 
 $conn=mysqli_connect("host","username","password","DB_name");
   if(!$conn)
   {
       echo "Problem is server connection";
	   exit();
   }

?>