<?php include_once 'database.php';?>
<?php 
if(isset($_POST['list'])){
?>
<html>
<head>
    <link rel="stylesheet" href="./css/product.css" >
    <link rel="stylesheet" href="./css/style.css" >
    <link rel="stylesheet" href="./css/style2.css" >
</head>
</html>
<form action="./bill.php" method="post">
<div class="banner">
    <div class="bill">
<table>
<tr>
    <td><b>Product Name</b></td>
    <td><b>Product Price</b></td>
    <td><b>Quantity</b></td>
</tr>
<?php
session_start();
$Email = $_SESSION['Email'];
    foreach($_POST['list'] as $list){
        $query = " SELECT * FROM carttable WHERE Email = '$Email' AND Product_Id = '$list'";
        $res = mysqli_query($conn,$query);
        if($res){
            if(mysqli_num_rows($res)>0){
                while($rows=mysqli_fetch_assoc($res)){
 ?>
        <tr>
            <td><?php echo $rows['Product_Name'] ?></td>
            <td><?php echo $rows['Product_Price'] ?></td>
            <td><input style="background-color : transparent; height:30px; font-size:20px; width:100%  " type="number" name="quantity[]" > </td>
        </tr>
            <input type="hidden" name="id[]" value="<?php echo $list ?>" >
    <?php
                }
            }
        }
    }
    mysqli_close($conn);
    ?>
    
    <tr><td colspan="3"><button type="submit" >Next</button></td>  </tr>
</table>
    </div>
    </div>
</form>


<?php 
    }else{
        header("Location:./mycart.php");
    }
?>



















