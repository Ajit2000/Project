<?php include_once 'database.php';?>
<?php
require 'PHPMailerAutoload.php';
require 'credentials.php';
$mail = new PHPMailer;

$mail->SMTPDebug = 3;                               // Enable verbose debug output

$mail->isSMTP();                                      // Set mailer to use SMTP
$mail->Host = 'smtp.gmail.com';  // Specify main and backup SMTP servers
$mail->SMTPAuth = true;                               // Enable SMTP authentication
$mail->Username = EMAIL;                 // SMTP username
$mail->Password = PASS;                           // SMTP password
$mail->SMTPSecure = 'tls';                            // Enable TLS encryption, `ssl` also accepted
$mail->Port = 587;                                    // TCP port to connect to

$mail->setFrom(EMAIL, 'Online Shopping Portal');
$mail->addAddress($_POST['cemail']);     // Add a recipient
//$mail->addAddress('ellen@example.com');               // Name is optional
$mail->addReplyTo(EMAIL);
//$mail->addCC('cc@example.com');
//$mail->addBCC('bcc@example.com');

//$mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
//$mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name

$mail->isHTML(true);                                  // Set email format to HTML

$mail->Subject = 'Order Placed Successfully';
$mail->Body    = "Hey <b>".$_POST['cname']."</b>, Your recent order will get deliver on the <b>Address ".$_POST['address']."</b>. Order summary is provided below. <br><p>Product Name : "
.$_POST['pname']."<br>Amount : ".$_POST['amount'].
"<br><p><b>Thanks for shopping...<b>";
$mail->AltBody = '';

if(!$mail->send()) {
    echo 'Message could not be sent.';
    echo 'Mailer Error: ' . $mail->ErrorInfo;
} else {
    $email = $_POST['cemail'];
    $pname = $_POST['pname'];
    $amount = $_POST['amount'];
    $query = "INSERT INTO ordertable(Email,Product_Name, Amount) VALUES ('$email','$pname','$amount')";
    
    $res=mysqli_query($conn,$query);
            if($res)
            {
                header("Location:./myorders.php");
            }else{
                echo "<h1>Record not inserted successfully</h1>";
            }
     mysqli_close($conn);
}
?>