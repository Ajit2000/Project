<?php include_once 'database.php';?>
<?php
$email = $_GET['x'];
$otp = $_GET['y'];
if(isset($_POST['submit']))
{
        if((int)$otp == (int)$_POST['otp']){
            $Email=$_POST['username'];
            $Password=$_POST['newpassword'];
            $cpassword = $_POST['confirmpassword'];
            if($Password == $cpassword){
            $query="update registertable SET Password = '$Password'  where Email = '$Email'";

                $res=mysqli_query($conn,$query);
                if($res)
                {
                   // echo "<h1>Record inserted successfully</h1>";
                    header("Location:./login.php");
                }else{
                    echo "<h1>Record not updated successfully</h1>";
                }
            }else{
                echo "PASSWORD IS INCORRECT!";
            }
                   mysqli_close($conn);
        }else{
            echo "OTP IS INCORRECT!";
        }

}
?>
<html>
    <head>
        <link rel="stylesheet", href="./css/style.css">  
    </head>
    <body>
	<form action = "" method = "post">
        <div class="banner">
            <div class="login-box">
            <h1 style="font-size: 28px;">Reset Password</h1>
            <div class="textbox">
                <i class="fa fa-user" aria-hidden="true"></i>
                 <input type="email" placeholder="Username" name="username" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" value="<?php echo $email ?>" required>
            </div>
                <div class="textbox">
                 <i class="fa fa-user" aria-hidden="true"></i>
                 <input type="text" placeholder="Enter OTP " name="otp" required>
            </div>
             <div class="textbox">
                 <i class="fa fa-lock" aria-hidden="true"></i>
                 <input type="password" placeholder="New Password" name="newpassword" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}"  title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" required>
            </div>
            <div class="textbox">
                 <i class="fa fa-lock" aria-hidden="true"></i>
                 <input type="password" placeholder="confirm Password" name="confirmpassword" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}"  title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" required>
            </div>
                    <button type="submit" class="button-style" style="width: 100%" name="reset" ><span></span>Reset</button>
        </div>
        </div>
        </form>
    </body>
</html>