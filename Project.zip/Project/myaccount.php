<?php include_once 'database.php';?>

<?php
    session_start();
    $username = $_SESSION['Email'];
    
    $query="SELECT * FROM registertable WHERE Email = '$username'";

    $res=mysqli_query($conn,$query);
    if($res){		
    if(mysqli_num_rows($res)>0){
        while($row=mysqli_fetch_assoc($res)){
?>
<html>
    <head>
        <link rel="stylesheet", href="./css/style.css">  
    </head>
    <body>
        <div class="banner">
            <div class="contact-us">
                <h1>My Profile</h1>
                
        <div class="txt">  
            <label>First Name : <?php echo $row['First_Name']?></label>          
        </div>
        
        <div class="txt">  
            <label>Last Name : <?php echo $row['Last_Name']?></label>          
        </div>
                
        <div class="txt">
            <label>Email : <?php echo $row['Email']?> </label>
        </div>
            
        <div class="txt">
            <label>Phone Number : <?php echo $row['Mobile_Number']?></label> 
        </div> 
    
        <div class="txt">
            <label>Address : <?php echo $row['Address']?></label>
        </div>
                

        <a class="btn-send" href="./myaccountEdit.php">Edit</a>
                
            </div>
        </div>
    </body>
</html>


<?php
        }
    }
        mysqli_close($conn);
}


?>