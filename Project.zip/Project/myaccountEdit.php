<?php include_once 'database.php';?>
<?php
session_start();
    $username = $_SESSION['Email'];
if(isset($_POST['submit']))
{
        $Fname=$_POST['firstname'];
        $Lname=$_POST['lastname'];
        $address=$_POST['address'];
        $phNo=$_POST['mobileno'];
       // $Email=$_POST['email'];
		
         $query="UPDATE registertable SET First_Name= '$Fname',Last_Name = '$Lname',Address = '$address',Mobile_Number = '$phNo' WHERE  Email = '$username'";

            $res=mysqli_query($conn,$query);
            if($res)
            {
               // echo "<h1>Record inserted successfully</h1>";
                header("Location:./myaccount.php");
            }else{
                echo "<h1>Record not inserted successfully</h1>";
            }
        
    
}
        //select query data code
        
        $query="SELECT * FROM registertable WHERE Email = '$username'";

        $res=mysqli_query($conn,$query);
        if($res){		
        if(mysqli_num_rows($res)>0){
        while($row=mysqli_fetch_assoc($res)){

               

?>

<html>
    <head>
        <link rel="stylesheet", href="./css/style.css">  
    </head>
    <body>
        <form action="" method="post">
    <div class="banner">
        <div class="contact-us">
            <h1>My Profile</h1>
            
        <div class="txt">
            <label>First Name :</label>
            <input type="text" name="firstname" value="<?php echo $row['First_Name']?>" placeholder="Enter Your Name">
        </div>
            
        <div class="txt">
            <label>Last Name :</label>
            <input type="text" name="lastname" value="<?php echo $row['Last_Name']?>" placeholder="Enter Your Name">
        </div>
        
<!--
        <div class="txt">
            <label>Email :</label>
            <input type="email" name="email" value="<?php echo $row['Email']?>" placeholder="Enter Your Email">
        </div>
-->
            
        <div class="txt">
            <label>Phone Number :</label>
            <input type="text" name="mobileno" value="<?php echo $row['Mobile_Number']?>" placeholder="Enter Your Phone Number">
        </div> 
        
        <div class="txt">
            <label>Address :</label>
            <input type="text" name="address" value="<?php echo $row['Address']?>" placeholder="Enter Your Name">
        </div>        
            
        <button class="btn-send" type="submit" name="submit">Update</button>  
            
        </div> 
    </div>
    </form>
    </body>
</html>


<?php
            }
        }
    
    }
        mysqli_close($conn);


?>