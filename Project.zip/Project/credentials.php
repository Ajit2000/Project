<?php
	define('EMAIL', 'Email Addresss');
	define('PASS', 'Password');
?>