<?php include_once 'database.php';?>
<html>
<head>
    <link rel="stylesheet" href="./css/product.css" >
</head>
<body>
<form action="./order.php" method="post">
    <div class="navbar-main">
                <h2>ONLINE SHOPPING PORTAL</h2>
                <ul>
                    <li><button style="background-color: yellow; height:30px"  type="submit">Order</button></li>
                    <li><a href="./products.php">HOME</a></li>
        </ul>
</div>
<?php
session_start();
$Email = $_SESSION['Email'];
$query="SELECT * FROM carttable WHERE Email = '$Email' ";
$res=mysqli_query($conn,$query);
if($res){
    if(mysqli_num_rows($res)>0){
        while($rows=mysqli_fetch_assoc($res)){
 ?>
<div class="outer1">
    <div class = "inner1">
    <img class="img"  src="./images/<?php echo $rows['Product_Name']; ?>.jfif">
    </div>
    <div class="inner2">
    <h3><?php echo $rows['Product_Name']; ?> </h3>
    <h3>₹ <?php echo $rows['Product_Price']; ?></h3>
    <input type="checkbox" name="list[]" value="<?php  echo $rows['Product_Id']; ?>"><br><br>
     <a href="./removecartproduct.php?c=<?php  echo $rows['Product_Id']; ?>"> <button type="button" class="btn">  Remove </button></a>
        
    </div>
</div>
<?php       }
        }
    }
    
        mysqli_close($conn);

?>
</form>
    </body>
</html>