<?php include_once 'database.php';?>
<?php 
     session_start();
    $Email = $_SESSION['Email'];
    $item=$_POST['item'];
    $Pid = $_POST['Pid'];
    $Price = $_POST['Price'];

     $query = " INSERT INTO `carttable` (`Email`, `Product_Id`, `Product_Name`, `Product_Price`) VALUES ('$Email','$Pid','$item','$Price')";
        $res=mysqli_query($conn,$query);
        if($res)
        {
         //   echo "<h1>Record inserted successfully</h1>";
           header("Location:./products.php");
        }else{
            echo "<h1>Record not inserted successfully</h1>";
        }
           mysqli_close($conn);
?>