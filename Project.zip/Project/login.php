<?php include_once 'database.php';?>
<?php
session_start();
if(isset($_SESSION['Email'])){
    header("Location:./index.php");
}else{
$error = '';
if(isset($_GET['x'])){
    $error = $_GET['x'];
}
//echo "<h1>".$error."</h1>";
if(isset($_POST['submit']))
{   
    $username = $_POST['username'];
    $password = $_POST['password'];
    
    $sql="SELECT * FROM admintable WHERE Email = '$username'";
    #ADMIN LOGIN
    $result=mysqli_query($conn,$sql);
    if($result){		
        if(mysqli_num_rows($result)>0){
            while($row=mysqli_fetch_assoc($result)){
                if($password==$row['Password']){
                   // session_start();
                    $_SESSION['Email']=$username;
                    header("Location:./admin/adminpage.php");                        
             }
            }               
         }
        }
    #USER LOGIN    
    $query="SELECT * FROM registertable WHERE Email = '$username'";

    $res=mysqli_query($conn,$query);
    if(!$res){
        header("Location:./login.php?x=Check Email and Password");
    }else{		
    if(mysqli_num_rows($res)>0){
        while($row=mysqli_fetch_assoc($res)){
           if($password==$row['Password']){
                session_start();
                $_SESSION['Email']=$username;
                header("Location:./products.php");                        
             }else{
                header("Location:./login.php?x=Check Email and Password");
            }               
         }
        }
    }
        mysqli_close($conn);
}
}
?>

<html>
    <head>
        <link rel="stylesheet", href="./css/style.css">  
    </head>
    <body>
	<form action = "" method = "post">
        <div class="banner">
            <div class="login-box">
            <h1>LOGIN</h1>
            <div class="textbox">
                <i class="fa fa-user" aria-hidden="true"></i>
                 <input type="email" placeholder="Username" name="username" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" required>
            </div>
             <div class="textbox">
                 <i class="fa fa-lock" aria-hidden="true"></i>
                 <input type="password" placeholder="Password" name="password" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}"  title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" required>
            </div>
                 <p style = "text-align: right"><a href="./resetPassword.php" >forgot password</a></p>
                    <button type="submit" class="button-style" style="width: 100%" name="submit" ><span></span>LOGIN</button>
        </div>
        </div>
        </form>
    </body>
</html>