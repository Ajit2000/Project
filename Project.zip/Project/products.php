<?php include_once 'database.php';?>

<?php 
$Name =null;
session_start();
 if(isset($_SESSION['Email'])){
     $Email = $_SESSION['Email'];
 }else{
     $Email = null;
 }
 $query="SELECT * FROM registertable WHERE Email = '$Email'";

        $res=mysqli_query($conn,$query);
        if($res){ 
        if(mysqli_num_rows($res)>0){
         while($row=mysqli_fetch_assoc($res)){
              $Name = $row['First_Name']." ".$row['Last_Name'];   
         }
        }
    }
?>

<html>
    <head>
     <link rel="stylesheet" href="./css/product.css">
    </head>
<body>  
 <div class="navbar-main">
                <h2>ONLINE SHOPPING PORTAL</h2>
                <ul>
                    <li><a href="./index.php">HOME</a></li>
                    <div class="dropdown" >
                        <li><a href="#"><?php echo $Name ?></a></li>
                            <div class="dropdown-content">
                                <a href="./myaccount.php">Profile</a>
                                <a href="./mycart.php">Cart</a>
                                <a href="./myorders.php">Orders</a>
                                <a href="./logout.php">Logout</a>
                            </div>
                    </div>
                </ul>
</div>

<?php
    $sql="SELECT * FROM producttable";

        $result=mysqli_query($conn,$sql);
        if($result){ 
        if(mysqli_num_rows($result)>0){
         while($rows=mysqli_fetch_assoc($result)){
             $productName = '';
             $myString = $rows['Product_Name'];
             $myArray = str_split($myString);
             foreach($myArray as $character){
                 if($character != '.'){
                    $productName = $productName.$character; 
                 }else{
                     break;
                 }
             }
?>
<div class="outer1">
    <div class = "inner1">
    <img class="img"  src="./images/<?php echo $rows['Product_Name']; ?>">
    </div>
    <div class="inner2">
    <form action="./addtocart.php" method="post">
    <input type="hidden" name="item" value="<?php  echo  $productName; ?>">
    <input type="hidden" name="Pid" value="<?php  echo $rows['Product_Id']; ?>">
    <input type="hidden" name="Price" value="<?php  echo $rows['Product_Price']; ?>">
    <h3><?php echo $productName; ?> </h3>
    <h3>₹ <?php echo $rows['Product_Price']; ?></h3>
    <p><?php echo $rows['Product_Info']; ?></p>
    <button class = "btn" type="submit"  >Add to cart</button>
    </form>
    </div>
</div>
<?php       }
        }
    }
    
        mysqli_close($conn);

?>

</body>

</html>