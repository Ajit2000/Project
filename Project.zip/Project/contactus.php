<html>
    <head>
        <link rel="stylesheet", href="./css/style.css">  
    </head>
    <body>
    <div class="banner">
        <div class="contact-us">
            <h1>Contact Us</h1>
            
        <div class="txt">
            <label>Full Name :</label>
            <input type="text" name="" value="" placeholder="Enter Your Name">
        </div>
        
        <div class="txt">
            <label>Email :</label>
            <input type="email" name="" value="" placeholder="Enter Your Email">
        </div>
            
        <div class="txt">
            <label>Phone Number :</label>
            <input type="text" name="" value="" placeholder="Enter Your Phone Number">
        </div> 
        
        <div class="txt">
            <label>Message :</label>
            <textarea></textarea>
        </div>
            
        <a class="btn-send">Send</a>  
            
        </div> 
    </div>
    
    </body>
</html>